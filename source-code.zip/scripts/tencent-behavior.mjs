import vm from 'node:vm';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const source=readFileSync(new URL('../extension/engine.js',import.meta.url),'utf8');
class Input{constructor(){this.tagName='TEXTAREA';this.type='textarea';this._value='';this.isConnected=true;}get value(){return this._value;}set value(v){this._value=v;}getClientRects(){return [1];}getAttribute(){return null;}closest(){return this.locked?{}:null;}dispatchEvent(){}}
function fixture({closed='',readonly=false,gradeOptions=['2025级','2026级','2026级（专升本）'],duplicate=false}={}){
  const values={college:'示例学院',grade:'2026级（专升本）',major:'示例专业',studentId:'001234',name:'示例同学'};
  const controls=[];let clicks=0;const body={innerText:closed};
  const specs=[['college','学院'],['grade','年级'],['major','专业（全称）'],['studentId','学号（不加0）'],['name','姓名']];
  if(duplicate)specs.push(['name','姓名']);
  const cards=specs.map(([key,title])=>{const input=new Input();input.disabled=readonly;input.locked=readonly;input.key=key;const radios=key==='grade'?gradeOptions.map(label=>({label,checked:false,isConnected:true,getClientRects:()=>[1],querySelector:()=>({textContent:label}),getAttribute(name){return name==='aria-checked'?String(this.checked):null;},closest:()=>readonly?{}:null,click(){for(const r of radios)r.checked=r===this;}})):[];controls.push(...(radios.length?radios:[input]));return {key,input,radios,getClientRects:()=>[1],querySelector:()=>({textContent:title}),querySelectorAll(selector){return selector==='[role="radio"]'?radios:radios.length?[]:[input];}};});
  const button={innerText:'提交',disabled:false,getClientRects:()=>[1],getAttribute:()=>null,click:()=>clicks++};
  const context=vm.createContext({document:{body,querySelectorAll:s=>s==='.question-main-content'?cards:[button]},location:{origin:'https://docs.qq.com',pathname:'/form/page/example',search:''},getComputedStyle:()=>({visibility:'visible'}),HTMLTextAreaElement:Input,HTMLInputElement:Input,Event:class{},setTimeout});
  vm.runInContext(source,context);
  return {values,cards,body,clicks:()=>clicks,run:(mode,signature,profile=values)=>context.quickfillEngine({mode,signature,profile})};
}
const f=fixture();let result=await f.run('inspect');assert.equal(result.status,'inspected');assert.ok(f.cards.every(c=>!c.input.value));assert.equal(f.clicks(),0);const signature=result.signature;
result=await f.run('fill');assert.equal(result.filled,5);assert.equal(f.cards.find(c=>c.key==='studentId').input.value,'001234','student ID must not be converted to a number');assert.equal(f.cards.find(c=>c.key==='grade').radios[2].checked,true);assert.equal(f.cards.find(c=>c.key==='grade').radios[1].checked,false);
result=await f.run('submit',signature);assert.equal(result.status,'submitted_unverified');assert.equal(f.clicks(),1);
for(const closed of ['已达收集上限','已暂停收集','收集表登录后才能填写','未开始收集']){const f=fixture({closed,readonly:true});assert.equal((await f.run('inspect')).status,'inspected');assert.equal((await f.run('fill')).status,'needs_action');assert.ok(f.cards.every(c=>!c.input.value));assert.equal(f.clicks(),0);}
{const f=fixture({gradeOptions:['2025级','2026级']});assert.equal((await f.run('fill')).status,'needs_action');assert.ok(f.cards.every(c=>!c.input.value));}
{const f=fixture();assert.equal((await f.run('fill','',{...f.values,major:''})).status,'needs_action');assert.ok(f.cards.every(c=>!c.input.value));assert.equal((await f.run('submit','different')).status,'needs_action');assert.equal(f.clicks(),0);}
{const f=fixture({duplicate:true});assert.equal((await f.run('fill')).status,'needs_action');assert.equal(f.clicks(),0);}
console.log('Tencent tests passed: five independent fields, exact 专升本 option, ID preservation, read-only inspection, full/login/not-open stops, missing-data/schema/duplicate stops, single submit click.');
