import vm from 'node:vm';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const engineSource=readFileSync(fileURLToPath(new URL('../extension/engine.js',import.meta.url)),'utf8');
class Input {
  constructor(label,key,required=true){this.labels=[{innerText:label}];this.name=key;this.id=key;this.type='text';this.tagName='INPUT';this.required=required;this._value='';this.disabled=false;this.readOnly=false;}
  set value(v){this._value=String(v);} get value(){return this._value;}
  getClientRects(){return [1];} getAttribute(){return null;} dispatchEvent(){}
  checkValidity(){return !this.required||!!this.value;}
}
function fixture({duplicate=false,missing=false,captcha=false,iframe=false,buttons=1}={}){
  let clicks=0;
  const input=[new Input('姓名','name'),new Input('学号','studentId'),new Input('手机号','phone')];
  if(duplicate)input.push(new Input('姓名','duplicate'));
  if(missing)input.push(new Input('未提供的必填字段','unknown'));
  const submit=Array.from({length:buttons},()=>({innerText:'提交',getClientRects:()=>[1],getAttribute:()=>null,closest:()=>null,click:()=>clicks++}));
  const context=vm.createContext({document:{body:{innerText:captcha?'请输入验证码':'报名表'},querySelectorAll(selector){if(selector==='input,textarea,select')return input;if(selector.startsWith('input[required]'))return input.filter(x=>x.required);if(selector.startsWith('button,'))return submit;return [];},querySelector:s=>s==='iframe'&&iframe?{}:null,getElementById:()=>null,getElementsByName:()=>[]},location:{origin:'https://forms.example',pathname:'/apply',search:''},getComputedStyle:()=>({visibility:'visible'}),HTMLInputElement:Input,HTMLTextAreaElement:Input,Event:class{}});
  vm.runInContext(engineSource,context);
  const run=task=>context.quickfillEngine(task);
  return {run,input,clicks:()=>clicks};
}
const profile={name:'测试同学',studentId:'TEST-001',phone:'13800138000'};
{
  const f=fixture();const filled=f.run({profile,mode:'fill'});assert.equal(filled.status,'prefilled');assert.equal(filled.filled,3);assert.equal(f.clicks(),0);
  assert.equal(f.run({profile,mode:'submit',signature:filled.signature}).status,'submitted_unverified');assert.equal(f.clicks(),1);
}
for(const [options,reason]of [[{duplicate:true},'ambiguous fields'],[{missing:true},'missing required field'],[{captcha:true},'human verification'],[{iframe:true},'embedded form'],[{buttons:2},'ambiguous submit button']]){
  const f=fixture(options);const filled=f.run({profile,mode:'fill'});const result=f.run({profile,mode:'submit',signature:filled.signature});assert.equal(result.status,'needs_action',reason);assert.equal(f.clicks(),0,reason);
}
{
  const f=fixture();assert.equal(f.run({profile,mode:'submit',signature:'old-form'}).status,'needs_action');assert.equal(f.clicks(),0);
}
// Mock browser APIs to test scheduling behavior without installing or driving a browser.
const store={},alarms=new Map();let hostAllowed=true,opened=0;const events={};
const event=name=>({addListener(fn){events[name]=fn;},removeListener(){}});
const chrome={
  storage:{local:{async get(key){if(key===null)return {...store};return typeof key==='string'?{[key]:store[key]}:Object.fromEntries(key.map(k=>[k,store[k]]));},async set(obj){Object.assign(store,obj);},async remove(key){for(const k of Array.isArray(key)?key:[key])delete store[k];}}},
  permissions:{contains:async()=>hostAllowed},
  runtime:{getURL:path=>'chrome-extension://test/'+path,onMessage:event('message'),onStartup:event('startup'),onInstalled:event('installed')},
  tabs:{async create(){opened++;return {id:opened};},async get(){return {status:'complete'};},onUpdated:event('updated')},
  scripting:{async executeScript(args){if(args.files)return [];return [{result:{status:'prefilled',message:'3 fields',filled:3,signature:'native-form'}}];}},
  alarms:{async create(name,args){alarms.set(name,args);},async clear(name){return alarms.delete(name);},async get(name){return alarms.get(name);},onAlarm:event('alarm')}
};
const context=vm.createContext({chrome,URL,console,setTimeout,clearTimeout,Date,Error,JSON});
vm.runInContext(readFileSync(fileURLToPath(new URL('../extension/background.js',import.meta.url)),'utf8'),context);
const sender={url:'https://majbhk.github.io/qingfill/'};
const task={id:'test-task',name:'Test task',url:'https://forms.example/apply',profile,time:new Date(Date.now()+120000).toISOString(),mode:'fill'};
await assert.rejects(()=>context.route({type:'PING'},{url:'https://untrusted.example/'}),/来源/);
for(const url of ['https://majbhk.github.io/other/','https://majbhk.github.io/qingfill-other/'])await assert.rejects(()=>context.route({type:'PING'},{url}),/来源/);
await assert.rejects(()=>context.route({type:'SCHEDULE',payload:{task:{...task,mode:'submit'}}},sender),/自动提交前/);
await context.route({type:'SCHEDULE',payload:{task}},sender);assert.equal(store['status:test-task'].status,'scheduled');assert.ok(alarms.has('qf:test-task'));
await assert.rejects(()=>context.route({type:'RUN',payload:{task}},sender),/已经安排/);
await context.route({type:'CANCEL',payload:{id:task.id}},sender);assert.ok(!store['job:test-task']);assert.ok(!alarms.has('qf:test-task'));
await context.route({type:'RUN',payload:{task}},sender);assert.equal(store['status:test-task'].status,'prefilled');assert.ok(store['verified:test-task']);
await context.route({type:'SCHEDULE',payload:{task:{...task,mode:'submit'}}},sender);
store['job:test-task'].task.time=new Date(Date.now()-120000).toISOString();const before=opened;await events.alarm({name:'qf:test-task'});assert.equal(opened,before);assert.equal(store['status:test-task'].status,'needs_action');
hostAllowed=false;const queued=await context.route({type:'RUN',payload:{task}},sender);assert.equal(queued.pendingPermission,true);assert.ok(store['pending:test-task']);
await context.route({type:'FORGET',payload:{id:task.id}},sender);assert.ok(!store['pending:test-task']);assert.ok(!store['verified:test-task']);
console.log('Passed: prefill, one submit click, ambiguity/missing/captcha/iframe/changed-form stops, source isolation, host authorization, scheduling, cancellation, and overdue-task handling.');
