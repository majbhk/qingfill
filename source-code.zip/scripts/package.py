from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil
root = Path(__file__).resolve().parents[1]
shutil.copy2(root / 'extension/engine.js', root / 'docs/engine.js')
with ZipFile(root / 'docs/quickfill-extension.zip', 'w', ZIP_DEFLATED) as archive:
    for path in sorted((root / 'extension').glob('*')):
        if path.is_file(): archive.write(path, path.name)
print('Packaged shared engine and browser extension.')
