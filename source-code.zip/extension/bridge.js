'use strict';
const allowed=new Set(['PING','STATUS','RUN','INSPECT','SCHEDULE','CANCEL','FORGET']);
window.addEventListener('message',async event=>{
  if(event.source!==window||event.origin!==location.origin||event.data?.source!=='QF_WEB'||!allowed.has(event.data.type))return;
  const {id,type,payload}=event.data;
  if(typeof id!=='string')return;
  try{
    const response=await chrome.runtime.sendMessage({type,payload});
    window.postMessage({source:'QF_EXTENSION',id,...response},location.origin);
  }catch(e){window.postMessage({source:'QF_EXTENSION',id,error:'助手连接中断，请刷新网页。'},location.origin);}
});
