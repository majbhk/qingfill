'use strict';
const SITE='https://majbhk.github.io/qingfill';
function isTrustedSite(raw){try{const url=new URL(raw),site=new URL(SITE);return url.origin===site.origin&&(url.pathname===site.pathname||url.pathname.startsWith(site.pathname+'/'));}catch{return false;}}
const locks=new Set();
const statusKey=id=>'status:'+id;
const jobKey=id=>'job:'+id;
const verifyKey=id=>'verified:'+id;
const pendingKey=id=>'pending:'+id;
async function read(key){return (await chrome.storage.local.get(key))[key];}
async function status(id,value,message){const obj={status:value,message,updatedAt:Date.now()};await chrome.storage.local.set({[statusKey(id)]:obj});return obj;}
function validateTask(input){
  if(!input||typeof input.id!=='string'||input.id.length>100)throw Error('无效任务编号');
  const url=new URL(input.url);if(url.protocol!=='https:'||url.username||url.password)throw Error('仅支持 HTTPS 报名表');
  const profile={};for(const key of ['name','studentId','grade','college','major','phone','school','className','extraLabel','extraValue'])profile[key]=String(input.profile?.[key]||'').slice(0,300);
  if(!profile.name||!profile.studentId||(profile.phone&&!/^1\d{10}$/.test(profile.phone)))throw Error('请先保存姓名和学号；手机号选填，填写时需有效');
  const mode=['submit','inspect'].includes(input.mode)?input.mode:'fill';
  return {id:input.id,name:String(input.name||'报名任务').slice(0,80),url:url.href,origin:url.origin,profile,mode,time:input.time||''};
}
async function requireHost(task,action){
  if(await chrome.permissions.contains({origins:[task.origin+'/*']}))return true;
  await chrome.storage.local.set({[pendingKey(task.id)]:{task,action}});
  await chrome.tabs.create({url:chrome.runtime.getURL('approve.html')+'?id='+encodeURIComponent(task.id)});
  return false;
}
function waitLoaded(tabId){return new Promise((resolve,reject)=>{
  let done=false;
  const finish=(err)=>{if(done)return;done=true;clearTimeout(timer);chrome.tabs.onUpdated.removeListener(listener);err?reject(err):resolve();};
  const listener=(id,change)=>{if(id===tabId&&change.status==='complete')finish();};
  const timer=setTimeout(()=>finish(Error('报名页面加载超时，请手动打开并登录后重新试填。')),18000);
  chrome.tabs.onUpdated.addListener(listener);
  chrome.tabs.get(tabId).then(tab=>{if(tab.status==='complete')finish();}).catch(finish);
});}
async function execute(task,isScheduled=false){
  if(locks.has(task.id))throw Error('此任务正在执行，请稍后查看结果');
  locks.add(task.id);
  try{
    if(isScheduled){const job=await read(jobKey(task.id));if(!job||job.phase!=='scheduled')return;job.phase='executing';await chrome.storage.local.set({[jobKey(task.id)]:job});}
    const verified=await read(verifyKey(task.id));
    if(task.mode==='submit'&&(!verified||verified.url!==task.url||verified.profile!==JSON.stringify(task.profile)))throw Error('请先用当前资料检查腾讯表单或完成预填，核对后再开启自动提交。');
    const tab=await chrome.tabs.create({url:task.url,active:true});
    await waitLoaded(tab.id);
    if(isScheduled){const job=await read(jobKey(task.id));if(!job||job.phase!=='executing')return;}
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['engine.js']});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:async args=>{
      if(location.origin!==args.origin)return {status:'needs_action',message:'页面跳转到其他网站，请先完成登录后重新试填。'};
      // Give a client-rendered form time to mount; never retry a submit.
      const started=Date.now();
      while(!document.querySelector('input:not([type=hidden]):not([type=password]),textarea,select')&&Date.now()-started<4000)await new Promise(resolve=>setTimeout(resolve,250));
      return quickfillEngine(args);
    },args:[{profile:task.profile,mode:task.mode,origin:task.origin,signature:verified?.signature}]});
    const result=results[0]?.result;
    if(!result)throw Error('未收到表单填写结果，请在原页面检查');
    if(['prefilled','inspected'].includes(result.status)&&result.signature)await chrome.storage.local.set({[verifyKey(task.id)]:{signature:result.signature,url:task.url,profile:JSON.stringify(task.profile)}});
    await status(task.id,result.status,result.message);
    return result;
  }catch(e){await status(task.id,'needs_action',e.message||'执行失败，请在原页面处理');throw e;}
  finally{if(isScheduled)await chrome.storage.local.remove(jobKey(task.id));locks.delete(task.id);}
}
async function schedule(task){
  const when=new Date(task.time).getTime();
  if(!Number.isFinite(when)||when<Date.now()+10000)throw Error('定时时间已过或距离当前时间太近');
  if(task.mode==='submit'){const v=await read(verifyKey(task.id));if(!v||v.url!==task.url||v.profile!==JSON.stringify(task.profile))throw Error('自动提交前，先用当前资料检查腾讯表单或完成预填，并核对原表单。');}
  if(locks.has(task.id))throw Error('任务正在执行，请稍后设置');
  await chrome.storage.local.set({[jobKey(task.id)]:{task,phase:'scheduled'}});
  await chrome.alarms.create('qf:'+task.id,{when});
  await status(task.id,'scheduled',task.mode==='submit'?'定时预填并点击提交一次；需核实原平台回执。':'定时预填；最后提交由你确认。');
  return {scheduled:true};
}
async function cancel(id){
  if(typeof id!=='string')throw Error('无效任务编号');
  if(locks.has(id))throw Error('任务已进入执行阶段，无法保证取消；请查看原页面。');
  await chrome.alarms.clear('qf:'+id);
  await chrome.storage.local.remove([jobKey(id),pendingKey(id)]);
  await status(id,'draft','定时任务已取消');
  return {cancelled:true};
}
async function route(message,sender){
  const internal=sender.url?.startsWith(chrome.runtime.getURL(''));
  if(!internal&&(!sender.url||!isTrustedSite(sender.url)))throw Error('此来源不可控制轻填助手');
  const {type,payload={}}=message;
  if(type==='PING')return {version:'1.1.1'};
  if(type==='STATUS'){const all=await chrome.storage.local.get(null);return Object.fromEntries(Object.entries(all).filter(([k])=>k.startsWith('status:')).map(([k,v])=>[k.slice(7),v]));}
  if(type==='CANCEL')return cancel(payload.id);
  if(type==='FORGET'){await cancel(payload.id);await chrome.storage.local.remove([verifyKey(payload.id),statusKey(payload.id)]);return {forgotten:true};}
  if(type==='RUN'||type==='INSPECT'||type==='SCHEDULE'){
    const task=validateTask(payload.task);
    if(type==='RUN')task.mode='fill';
    if(type==='INSPECT')task.mode='inspect';
    if(await read(jobKey(task.id)))throw Error('任务已经安排或执行中，请先取消现有定时任务');
    if(!await requireHost(task,type))return {pendingPermission:true};
    return type==='SCHEDULE'?schedule(task):execute(task);
  }
  if(type==='APPROVE'&&internal){
    const pending=await read(pendingKey(payload.id));if(!pending)throw Error('任务已取消或过期，请从网站重新发起');
    if(!await chrome.permissions.contains({origins:[pending.task.origin+'/*']}))throw Error('尚未授权这个报名平台');
    await chrome.storage.local.remove(pendingKey(payload.id));
    return pending.action==='SCHEDULE'?schedule(pending.task):execute(pending.task);
  }
  throw Error('不支持的操作');
}
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{route(msg,sender).then(result=>respond({result})).catch(error=>respond({error:error.message}));return true;});
chrome.alarms.onAlarm.addListener(async alarm=>{
  if(!alarm.name.startsWith('qf:'))return;
  const id=alarm.name.slice(3),job=await read(jobKey(id));
  if(!job||job.phase!=='scheduled')return;
  if(Date.now()-new Date(job.task.time).getTime()>60000){await chrome.storage.local.remove(jobKey(id));await status(id,'needs_action','已错过执行时间超过 60 秒，未自动补交，请手动处理。');return;}
  try{await execute(job.task,true);}catch{}
});
async function reconcile(){
  const all=await chrome.storage.local.get(null);
  for(const [key,job]of Object.entries(all)){
    if(!key.startsWith('job:'))continue;
    const id=key.slice(4);
    if(job.phase==='executing'){await chrome.storage.local.remove(key);await status(id,'needs_action','上次执行中断，结果未知。为避免重复提交，没有自动重试，请查看原平台。');continue;}
    const when=new Date(job.task.time).getTime();
    if(when<Date.now()){await chrome.storage.local.remove(key);await status(id,'needs_action','浏览器恢复时执行时间已过，未自动补交。');}
    else if(!await chrome.alarms.get('qf:'+id))await chrome.alarms.create('qf:'+id,{when});
  }
}
chrome.runtime.onStartup.addListener(reconcile);
chrome.runtime.onInstalled.addListener(reconcile);
